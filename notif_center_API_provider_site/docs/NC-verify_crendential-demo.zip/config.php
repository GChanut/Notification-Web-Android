<?php
define('CONSUMER_KEY', 'abcdef1234567890');
define('CONSUMER_SECRET', 'azertyuiop289674530');
define('OAUTH_CALLBACK', 'http://127.0.0.1/callback.php');
?>